import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';

import { ThemeProvider, useTheme } from './context/ThemeContext';
import { AudioProvider } from './context/AudioContext';
import { Colors } from './constants/colors';

import HomeScreen from './screens/HomeScreen';
import ControlsScreen from './screens/ControlsScreen';
import TranscriptScreen from './screens/TranscriptScreen';
import AIScreen from './screens/AIScreen';
import ProfileScreen from './screens/ProfileScreen';

const Stack = createStackNavigator();

function AppNavigator() {
  const { isDark } = useTheme();

  return (
    <>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <NavigationContainer>
        <Stack.Navigator
          screenOptions={{
            headerShown: false,
            cardStyle: {
              backgroundColor: isDark ? Colors.backgroundDark : Colors.background,
            },
            animationEnabled: true,
            gestureEnabled: true,
          }}
          initialRouteName="Home"
        >
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Controls" component={ControlsScreen} />
          <Stack.Screen name="Transcript" component={TranscriptScreen} />
          <Stack.Screen name="AI" component={AIScreen} />
          <Stack.Screen name="Profile" component={ProfileScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AudioProvider>
        <AppNavigator />
      </AudioProvider>
    </ThemeProvider>
  );
}
